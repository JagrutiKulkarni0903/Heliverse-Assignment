package AutomationAssignment;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FunctionalTest_with_HTMLReport {

		private static WebDriver driver;
		public static StringBuilder result;

		public  FunctionalTest_with_HTMLReport(String driverPath, String url) {
		        System.setProperty("webdriver.chrome.driver", driverPath);
		        this.driver = new ChromeDriver();
		        this.driver.get(url);
		        driver.manage().window().maximize();
		        System.out.println("Drivers are set and successfully opened the website-PASS");
		    }

		public void number_fill(By locator,String value) {
			WebElement number=driver.findElement(locator);
			number.clear();
			number.sendKeys(value);
			result.append("<tr><td>Filled field</td><td style='color:green;'>Pass</td></tr>");
		}
		
		public void continue_button(By locator) {
			WebElement button=driver.findElement(locator);
			if(button.isDisplayed()&& button.isEnabled()) {
			button.click();
			result.append("<tr><td>Clicked Submit Button</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Clicked Submit Button</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void enter_otp(String otp) {
			number_fill(By.xpath("//input[1]"), String.valueOf(otp.charAt(0)));
	        number_fill(By.xpath("//input[2]"), String.valueOf(otp.charAt(1)));
	        number_fill(By.xpath("//input[3]"), String.valueOf(otp.charAt(2)));
	        number_fill(By.xpath("//input[4]"), String.valueOf(otp.charAt(3)));
		}
		public void enter_otp_manually() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("Please enter the OTP received on your mobile: ");
	        String otp = scanner.nextLine();

	        // Now fill the OTP fields
	        try {
	            enter_otp(otp); // Call your existing method to enter OTP
	        } catch (Exception e) {
	            // Log failure result
	            result.append("<tr><td>Error entering OTP- " + e.getMessage() + "</td><td style='color:red;'>Fail</td></tr>");
	        }
	    }
		
		public void login_button(By locator) {
			WebElement loginbutton=driver.findElement(locator);
			if(loginbutton.isDisplayed()&& loginbutton.isEnabled()) {
			loginbutton.click();
			result.append("<tr><td>Clicked login Button</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Clicked login Button</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void confirmation(By locator) {
			WebElement display=driver.findElement(locator);
			if(display.isDisplayed()) {
			System.out.println("Successfully logged in");
			result.append("<tr><td>Logged in properly</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Logged in properly</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void navigation(By locator) {
			WebElement fashion=driver.findElement(locator);
			if(fashion.isDisplayed()&& fashion.isEnabled()) {
			fashion.click();
			System.out.println("Navigate to fashion");
			result.append("<tr><td>Navigate to fashion</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Navigate to fashion</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void choose_product(By locator) {
			WebElement product=driver.findElement(locator);
			if(product.isDisplayed() && product.isEnabled()) {
			product.click();
			//driver.navigate().to("");
			System.out.println("Selected a product");
			result.append("<tr><td>Selection of product</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Selection of product</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void addToCart(By locator) throws InterruptedException {
			WebElement add=driver.findElement(locator);
			WebElement cart=driver.findElement(locator);
			if(add.isDisplayed() && add.isEnabled()) {
			add.click();
			Thread.sleep(3000);
			if(cart.isDisplayed()) {
				cart.click();
			}
			System.out.println("Product added to cart");
			result.append("<tr><td>Add to cart</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Add to cart</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void visitCart(By locator) throws InterruptedException {
			WebElement cart=driver.findElement(locator);
			if(cart.isDisplayed()) {
			cart.click();
			System.out.println("Product added to cart");
			
			result.append("<tr><td>Add to cart</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Add to cart</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void clickpaytype(By locator) throws InterruptedException {
			WebElement paytype=driver.findElement(locator);
			if(paytype.isDisplayed()&& paytype.isEnabled()) {
			paytype.click();
			System.out.println("Button is selected");
			
			result.append("<tr><td>select pay type</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>select pay type</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		
		public void paybutton(By locator) throws InterruptedException {
			WebElement paybutton=driver.findElement(locator);
			if(paybutton.isDisplayed()&& paybutton.isEnabled()) {
				paybutton.click();
			System.out.println("Button is clicked");
			
			result.append("<tr><td>Click on payment button</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				result.append("<tr><td>Click on payment button</td><td style='color:red;'>Fail</td></tr>");
			}
		}

		public static void main(String[] args) {
			FunctionalTest_with_HTMLReport functionTest=new FunctionalTest_with_HTMLReport("C:\\Users\\Jagruti Kulkarni\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe","https://www.craftsvilla.com/");
			
			result=new StringBuilder();
			result.append("<html><head><title>Functional Test</title></head><body>");
			result.append("<h1 style='text-align:center';>Form Validation Test Report</h1>");
			result.append("<table border='1' style='width:100%; text-align:center;'>");
			result.append("<tr><th>Steps</th><th>Status</th></tr>");
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			try {
				
				driver.navigate().to("https://www.craftsvilla.com/login?redirect=my-account");
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Mobile Number *']")));
				
				functionTest.number_fill(By.xpath("//input[@placeholder='Mobile Number *']"), "8698372088");
				Thread.sleep(5000);
				
				functionTest.continue_button(By.xpath("//button[normalize-space()='CONTINUE']"));
				Thread.sleep(5000);
				
				functionTest.enter_otp_manually();
				Thread.sleep(5000);
				
				functionTest.login_button(By.xpath("//button[normalize-space()='LOGIN']"));
				Thread.sleep(5000);
				
				functionTest.confirmation(By.cssSelector("div[class='h1b']"));
				Thread.sleep(5000);
				
				functionTest.navigation(By.xpath("//body/div[@id='root']/div[@class='sc-lgVVsH burvHu']/div[@class='sc-jTYCaT lfyYco']/div[@class='sc-gPpHY bityGn']/div[@class='sc-ckCjom jQwVSg']/div[1]"));
				Thread.sleep(20000);
				
				functionTest.choose_product(By.xpath("//div[@class='sc-gILORG gtcLBx']//div[1]//div[1]//img[1]"));
				Thread.sleep(5000);
				
				functionTest.addToCart(By.xpath("//div[@class='sc-cZwWEu iSSQfd desktop-buy-now pdpBtns']//button[@type='submit'][normalize-space()='Add To Cart']"));
				Thread.sleep(5000);
				
				WebElement cut=driver.findElement(By.xpath("(//*[name()='svg'])[14]"));
				cut.isDisplayed();cut.isEnabled() ;
				cut.click();
				Thread.sleep(2000);
				
				functionTest.visitCart(By.xpath("//div[@class='sc-bGWzfD hMGObq']//span[@class='ant-badge css-1okl62o']"));
				Thread.sleep(5000);
				
				functionTest.clickpaytype(By.xpath("//span[@class='ant-radio ant-wave-target']"));
				Thread.sleep(5000);
				
				functionTest.paybutton(By.xpath("//button[normalize-space()='PAY NOW']"));
				Thread.sleep(5000);
				
				functionTest.result.append("<tr><td>Completed all the steps</td><td style='color:green;'>Pass</td></tr>");	
			}
			catch(Exception e) {
				functionTest.result.append("<tr><td>Error Occured:"+e.getMessage()+" </td><td style='color:red;'>Fail</td></tr>");
			}
			functionTest.driver.quit();
			
			//report generation
					try {
						FileWriter filewriter=new FileWriter("FunctionalTestReport.html");
						filewriter.write(result.toString());
						filewriter.close();
						System.out.println("Functional Test Report generated successfully-FunctionalTestReport.html");
					}
					catch(IOException e) {
						System.out.println("Error while generating report! "+e.getMessage());
					}

	}

}
