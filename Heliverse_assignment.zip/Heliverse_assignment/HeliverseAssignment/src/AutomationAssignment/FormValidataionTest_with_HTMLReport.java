package AutomationAssignment;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FormValidataionTest_with_HTMLReport {
	public WebDriver driver;
	public static StringBuilder result;
	
	public void number_fill(By locator,String value) {
		WebElement number=driver.findElement(locator);
		number.clear();
		number.sendKeys(value);
		result.append("<tr><td>Filled field </td><td style='color:green;'>Pass</td></tr>");
	}
	
	public void continue_button(By locator) {
		WebElement button=driver.findElement(locator);
		if(button.isDisplayed()&& button.isEnabled()) {
		button.click();
		result.append("<tr><td>Clicked Submit Button</td><td style='color:green;'>Pass</td></tr>");
		}
		else {
			result.append("<tr><td>Clicked Submit Button</td><td style='color:red;'>Fail</td></tr>");
		}
	}
	
	public void enter_otp(String otp) {
		number_fill(By.xpath("//input[1]"), String.valueOf(otp.charAt(0)));
        number_fill(By.xpath("//input[2]"), String.valueOf(otp.charAt(1)));
        number_fill(By.xpath("//input[3]"), String.valueOf(otp.charAt(2)));
        number_fill(By.xpath("//input[4]"), String.valueOf(otp.charAt(3)));
	}
	public void enter_otp_manually() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the OTP received on your mobile: ");
        String otp = scanner.nextLine();

        // Now fill the OTP fields
        try {
            enter_otp(otp); // Call your existing method to enter OTP
        } catch (Exception e) {
            // Log failure result
            result.append("<tr><td>Error entering OTP- " + e.getMessage() + "</td><td style='color:red;'>Fail</td></tr>");
        }
    }
	
	
	public void login_button(By locator) {
		WebElement loginbutton=driver.findElement(locator);
		if(loginbutton.isDisplayed()&& loginbutton.isEnabled()) {
		loginbutton.click();
		result.append("<tr><td>Clicked login Button</td><td style='color:green;'>Pass</td></tr>");
		}
		else {
			result.append("<tr><td>Clicked login Button</td><td style='color:red;'>Fail</td></tr>");
		}
	}

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Jagruti Kulkarni\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		FormValidataionTest_with_HTMLReport registration=new FormValidataionTest_with_HTMLReport();
		registration.driver=new ChromeDriver();
		registration.driver.manage().window().maximize();
		
		System.out.println("Drivers are set and successfully opened the website-PASS");
		
		registration.result=new StringBuilder();
		registration.result.append("<html><head><title>Form Validation Test</title></head><body>");
		registration.result.append("<h1 style='text-align:center';>Form Validation Test Report</h1>");
		registration.result.append("<table border='1' style='width:100%; text-align:center;'>");
		registration.result.append("<tr><th>Steps</th><th>Status</th></tr>");
     
		WebDriverWait wait = new WebDriverWait(registration.driver, Duration.ofSeconds(5));
		try {
			registration.driver.get("https://www.craftsvilla.com/");
			Thread.sleep(2000);
			
			registration.driver.navigate().to("https://www.craftsvilla.com/login?redirect=my-account");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Mobile Number *']")));
			
			registration.number_fill(By.xpath("//input[@placeholder='Mobile Number *']"), "9890143670");
			Thread.sleep(5000);
			registration.continue_button(By.xpath("//button[normalize-space()='CONTINUE']"));
			Thread.sleep(5000);
			registration.enter_otp_manually();
			Thread.sleep(5000);
			
			registration.login_button(By.xpath("//button[normalize-space()='LOGIN']"));
			Thread.sleep(5000);
			
			
			registration.result.append("<tr><td>Completed all the steps</td><td style='color:green;'>Pass</td></tr>");	
		}
		catch(Exception e) {
			registration.result.append("<tr><td>Error Occured:"+e.getMessage()+" </td><td style='color:red;'>Fail</td></tr>");
		}
		registration.driver.quit();
		
		//report generation
		try {
			FileWriter filewriter=new FileWriter("FormValidationTestReport.html");
			filewriter.write(result.toString());
			filewriter.close();
			System.out.println("Form Validation Test Report generated successfully-FormValidationTestReport.html");
		}
		catch(IOException e) {
			System.out.println("Error while generating report! "+e.getMessage());
		}
	}

}
