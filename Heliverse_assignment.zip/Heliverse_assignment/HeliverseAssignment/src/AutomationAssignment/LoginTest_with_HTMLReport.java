package AutomationAssignment;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginTest_with_HTMLReport {
	private static WebDriver driver;
	public static StringBuilder result;

	public  LoginTest_with_HTMLReport(String driverPath, String url) {
	        System.setProperty("webdriver.chrome.driver", driverPath);
	        this.driver = new ChromeDriver();
	        this.driver.get(url);
	        driver.manage().window().maximize();
	        System.out.println("Drivers are set and successfully opened the website-PASS");
	    }

	public void number_fill(By locator,String value) {
		WebElement number=driver.findElement(locator);
		number.clear();
		number.sendKeys(value);
		result.append("<tr><td>Filled field</td><td style='color:green;'>Pass</td></tr>");
	}
	
	public void continue_button(By locator) {
		WebElement button=driver.findElement(locator);
		if(button.isDisplayed()&& button.isEnabled()) {
		button.click();
		result.append("<tr><td>Clicked Submit Button</td><td style='color:green;'>Pass</td></tr>");
		}
		else {
			result.append("<tr><td>Clicked Submit Button</td><td style='color:red;'>Fail</td></tr>");
		}
	}
	
	public void enter_otp(String otp) {
		number_fill(By.xpath("//input[1]"), String.valueOf(otp.charAt(0)));
        number_fill(By.xpath("//input[2]"), String.valueOf(otp.charAt(1)));
        number_fill(By.xpath("//input[3]"), String.valueOf(otp.charAt(2)));
        number_fill(By.xpath("//input[4]"), String.valueOf(otp.charAt(3)));
	}
	public void enter_otp_manually() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the OTP received on your mobile: ");
        String otp = scanner.nextLine();

        // Now fill the OTP fields
        try {
            enter_otp(otp); // Call your existing method to enter OTP
        } catch (Exception e) {
            // Log failure result
            result.append("<tr><td>Error entering OTP- " + e.getMessage() + "</td><td style='color:red;'>Fail</td></tr>");
        }
    }
	
	public void login_button(By locator) {
		WebElement loginbutton=driver.findElement(locator);
		if(loginbutton.isDisplayed()&& loginbutton.isEnabled()) {
		loginbutton.click();
		result.append("<tr><td>Clicked login Button</td><td style='color:green;'>Pass</td></tr>");
		}
		else {
			result.append("<tr><td>Clicked login Button</td><td style='color:red;'>Fail</td></tr>");
		}
	}
	
	public void confirmation(By locator) {
		WebElement display=driver.findElement(locator);
		if(display.isDisplayed()) {
		System.out.println("Successfully logged in");
		result.append("<tr><td>Logged in properly</td><td style='color:green;'>Pass</td></tr>");
		}
		else {
			result.append("<tr><td>Logged in properly</td><td style='color:red;'>Fail</td></tr>");
		}
	}

	public static void main(String[] args) {
		LoginTest_with_HTMLReport setchromedriver=new LoginTest_with_HTMLReport("C:\\Users\\Jagruti Kulkarni\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe","https://www.craftsvilla.com/");
		
		result=new StringBuilder();
		result.append("<html><head><title>Login Form Test</title></head><body>");
		result.append("<h1 style='text-align:center';>Login Form Test Report</h1>");
		result.append("<table border='1' style='width:100%; text-align:center;'>");
		result.append("<tr><th>Steps</th><th>Status</th></tr>");
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		try {
			
			driver.navigate().to("https://www.craftsvilla.com/login?redirect=my-account");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Mobile Number *']")));
			
			setchromedriver.number_fill(By.xpath("//input[@placeholder='Mobile Number *']"), "8698372088");
			Thread.sleep(5000);
			
			setchromedriver.continue_button(By.xpath("//button[normalize-space()='CONTINUE']"));
			Thread.sleep(5000);
			
			setchromedriver.enter_otp_manually();
			Thread.sleep(5000);
			
			setchromedriver.login_button(By.xpath("//button[normalize-space()='LOGIN']"));
			Thread.sleep(5000);
			
			setchromedriver.confirmation(By.cssSelector("div[class='h1b']"));
			Thread.sleep(5000);
			
			setchromedriver.result.append("<tr><td>Completed all the steps</td><td style='color:green;'>Pass</td></tr>");	
		}
		catch(Exception e) {
			setchromedriver.result.append("<tr><td>Error Occured:"+e.getMessage()+" </td><td style='color:red;'>Fail</td></tr>");
		}
		setchromedriver.driver.quit();
		
		//report generation
				try {
					FileWriter filewriter=new FileWriter("LoginTestReport.html");
					filewriter.write(result.toString());
					filewriter.close();
					System.out.println("Login Test Report generated successfully-LoginTestReport.html");
				}
				catch(IOException e) {
					System.out.println("Error while generating report! "+e.getMessage());
				}
	}
	

}
