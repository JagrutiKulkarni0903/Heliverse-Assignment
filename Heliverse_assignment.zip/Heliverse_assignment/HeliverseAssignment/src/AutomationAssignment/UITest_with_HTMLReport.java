package AutomationAssignment;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UITest_with_HTMLReport {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Jagruti Kulkarni\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
		
		driver.get("https://www.craftsvilla.com/");
		Thread.sleep(2000);
		
		System.out.println("Drivers are set and successfully opened the website-PASS");
		
		StringBuilder result=new StringBuilder();
		result.append("<html><head><title> UI TEST</title></head><body>");
		result.append("<h1 style='text-align:center;'>UI Test Report</h1>");
		result.append("<table border='1' style='width:100%; text-align:center;'>");
		result.append("<tr><th>UI Elements</th><th>Test Result</th></tr>");
		
		//test script to test the ui element of search bar
		try {
			WebElement search_bar=driver.findElement(By.xpath("(//div[@class='sc-iTONeN fgBMjv searchMobile'])[1]"));
			WebElement searchbar_text=driver.findElement(By.xpath("//div[@class='sc-jmnVvD kkYnTe']//input[@placeholder='Search your item here']"));
			if(search_bar.isDisplayed() && searchbar_text.isEnabled()) { 
				searchbar_text.sendKeys("saree");
				Thread.sleep(2000);
				System.out.println("Search Bar is Displayed and Functional");
				result.append("<tr><td>Search Bar</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				System.out.println("Search Bar not Displayed");
				result.append("<tr><td>Search Bar</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		catch(Exception e) {
			result.append("<tr><td>Search Bar</td><td style='color:red;'Fail(Element not found)</td></tr>");	
		}
		
		//test script to test ui element navigation bar
		try {
			WebElement navigation_bar=driver.findElement(By.xpath("(//div[@class='sc-ckCjom jQwVSg'])[1]"));
			WebElement navigationbar_click=driver.findElement(By.xpath("//body/div[@id='root']/div[@class='sc-lgVVsH burvHu']/div[@class='sc-jTYCaT lfyYco']/div[@class='sc-gPpHY bityGn']/div[@class='sc-ckCjom jQwVSg']/div[1]"));
			if(navigation_bar.isDisplayed()){
				navigationbar_click.click();
				Thread.sleep(5000);
				System.out.println("Navigation Bar is Displayed and Functional");
				result.append("<tr><td>Navigation Bar</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				System.out.println("Navigation Bar not Displayed");
				result.append("<tr><td>Navigation Bar</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		catch(Exception e) {
			result.append("<tr><td>Navigation Bar</td><td style='color:red;'Fail(Element not found)</td></tr>");
		}
		
		//test script to test ui element footer
		try {
			WebElement footer=driver.findElement(By.xpath("(//div[@class='sc-igHpSv ifwQIG'])[1]"));
			if(footer.isDisplayed()) {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", footer);
				Thread.sleep(2000);
				System.out.println("Footer is Displayed");
				result.append("<tr><td>Footer</td><td style='color:green;'>Pass</td></tr>");
			}
			else {
				System.out.println("Footer not Displayed");
				result.append("<tr><td>Footer</td><td style='color:red;'>Fail</td></tr>");
			}
		}
		catch(Exception e) {
			result.append("<tr><td>Footer</td><td style='color:red;'Fail(Element not found)</td></tr>");
		}
		result.append("</table></body></html>");
		
		driver.quit();
		
		//report generation
		try {
			FileWriter filewriter=new FileWriter("UITestReport.html");
			filewriter.write(result.toString());
			filewriter.close();
			System.out.println("UI Test Report generated successfully-UITestReport.html");
		}
		catch(IOException e) {
			System.out.println("Error while generating report! "+e.getMessage());
		}
	}

}
